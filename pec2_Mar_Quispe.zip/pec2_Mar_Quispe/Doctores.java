package pec2_Mar_Quispe;
import java.util.Random;
public class Doctores extends Empleados {
	
	boolean grave;
	private String especialidad;
	private boolean True;

	public Doctores(String nombre, String apellidos, String dni, int id, int añosExperiencia, String turno,
			String especialidad) {
		super(nombre, apellidos, dni, id, añosExperiencia, turno);
		this.especialidad = especialidad;
	}

	public String getEspecialidad() {
		return especialidad;
	}

	public void setEspecialidad(String especialidad) {
		this.especialidad = especialidad;
	}

	
	

	@Override
	public void comer() {
		System.out.println("El enfermero" + this.getNombre()+ "esta comiendo en la cafeteria");
	}

	@Override
	public void fichar() {
		// TODO Auto-generated method stub
		super.fichar();
	}

	@Override
	public Boolean atenderPaciente(Boolean grave) {
		boolean valorAleatorio = new Random().nextBoolean();
		if (valorAleatorio==True){
          System.out.println("El paciente debe ser hospitalizado.");
		}
		else {
			System.out.println("El paciente no tiene porque ser hospitalizado");
		}
	}

	
	
}
