package pec2_Mar_Quispe;

public abstract class Enfermero extends Empleados {
	
	private int planta;

	public Enfermero(String nombre, String apellidos, String dni, int id, int añosExperiencia, String turno,
			int planta) {
		super(nombre, apellidos, dni, id, añosExperiencia, turno);
		this.planta = planta;
	}

	public int getPlanta() {
		return planta;
	}

	public void setPlanta(int planta) {
		this.planta = planta;
	}


	@Override
	public void comer() {
		System.out.println("El enfermero" + this.getNombre()+ "esta comiendo en la cafeteria");
	}

	@Override
	public void fichar() {
		// TODO Auto-generated method stub
		super.fichar();
		System.out.println("El enfermero esta fichando");
	}

	@Override
	public void examinarPaciente() {
		System.out.println("El enfermero "+this.getNombre()+" esta examinando al paciente "+ super.getNombre());
	}
	
	
	
	
}
