package pec2_Mar_Quispe;

public interface Fichable {

	void fichar();
	
}
