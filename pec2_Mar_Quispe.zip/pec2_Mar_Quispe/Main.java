package pec2_Mar_Quispe;

import javaucjc.pec1.Alumno;
import javaucjc.pec1.Colegio;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Empleados[] personas=new Empleados[2];
		Pacientes[]salaDeEspera =new Pacientes[4];
		Clinica[] clinica=new Clinica(nombre,direccion,empleados);
		
		Empleados doctor=new Doctores("nombre1","ap","334s");
		Empleados enfermero=new Enfermero();
		
		Persona paciente1=new Pacientes();
		Persona paciente2=new Pacientes();
		Persona paciente3=new Pacientes();
		Persona paciente4=new Pacientes();
		
		personas[0]=doctor;
		personas[1]=enfermero;
		
		salaDeEspera[0]=paciente1;
		salaDeEspera[1]=paciente2;
		salaDeEspera[2]=paciente3;
		salaDeEspera[3]=paciente4;
		

		
		
		
	}

	
	public void asignaPersonas(Clinica clinica,Empleado [] personas) {
		for (Empleado empleado: personas) {
			clinica.asignaPersonas(personas);
		}
	}
}
