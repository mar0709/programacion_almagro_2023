package pec2_Mar_Quispe;

public class Pacientes extends Personas {

	private String sintomas;

	public Pacientes(String nombre, String apellidos, String dni, String sintomas) {
		super(nombre, apellidos, dni);
		this.sintomas = sintomas;
	}

	public String getSintomas() {
		return sintomas;
	}

	public void setSintomas(String sintomas) {
		this.sintomas = sintomas;
	}

	
	@Override
	public void comer() {
		System.out.println("El paciente "+ this.getNombre()+ " esta comiendo en la calle");
	}
	
	
	
	
}
