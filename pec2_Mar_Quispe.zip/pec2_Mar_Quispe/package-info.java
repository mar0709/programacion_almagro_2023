package pec2_Mar_Quispe;

//Todos tienen nombre aperllidos y dni y todos van a comer, los doctores y los enfermeros en la cafetería del hospital, los pacientes 
//en la calle y los empleados en la cafetería (Ejemplo: El Enfermero nombreenfermero esta comiendo en la cafeteria). (1 pto)
//Los empleados del la clínica ademas van a poseer las cualidades id, años de experiencia y turno (mañana, tarde, noche) y van 
//a tener que fichar. (1 pto)
//El enfermero va a tener la planta donde se encuentra y el método examinar paciente donde solo se indicara que el enfermero
//(nombre) está examinando al paciente (nombre) (0,5 ptos) 
//Un doctor va a tener especialidad y va a tener que atender pacientes. (0,5 ptos) En el proceso se verá si el paciente esta grave 
//(se hace de manera aleatoria) Si está grave se indica que el paciente tiene que ser hospitalizado en caso contrario que se va del
//hospital (0,5 ptos)
//El paciente va a tener sintomas.(0,5 ptos)
//La clínica  va a tener un nombre, una dirección y tendrá un enfermero, un doctor, una sala de espera con 4 pacientes como mucho
//.(0,5 ptos)
//La clínica tendrá un método para que fichen todos sus empleados donde se indicara que el empleado con id está fichando (0,5 ptos)
//La clínica tendrá otro método para que
//    se atienda a los pacientes de la sala de espera indicando el nombre del paciente que se empieza a atender,(0,5 ptos)
//    donde el enfermero primero examinara al paciente (1 ptos)
//    luego el doctor atenderá al paciente.(1 pto)
//Otro método para poner a comer a todos. (1 pto)
//Crear una clase donde se creara 1 doctor, 1 enfermero, 4 pacientes y 1 Clinica. A partir de ahí se hará primero que fichen los
//empleados, luego se pondrá a todos (empleados y pacientes) a comer y por último se atenderá a todos los pacientes (1pto)
//Se tendrá en cuenta la creación de comentarios (0,1 punto), seguir los estandares para nombrar las clases, métodos y variables
//(0,2 puntos) y uso correcto de los métodos estáticos (0,2 puntos)
