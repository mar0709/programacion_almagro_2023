package pec2_Mar_Quispe;


public class Clinica implements Fichable,Comedero {
	
	private String nombre;
	private String direccion;
	private Pacientes [] salaDeEspera;
	private Empleados [] personas;
	
	public Clinica(String nombre, String direccion, Pacientes[] salaDeEspera,Empleados[] personas) {
		super();
		this.nombre = nombre;
		this.direccion = direccion;
		salaDeEspera =new Pacientes[4];
		personas= new Empleados[2];
		
	}
	public Clinica(String nombre, String direccion, Pacientes[] salaDeEspera,Empleados[] personas) {
		super();
		this.nombre = nombre;
		this.direccion = direccion;
		salaDeEspera =new Pacientes[4];
		personas= new Empleados[2];
	}
	
	

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	
	public Pacientes[] getSalaDeEspera() {
		return salaDeEspera;
	}

	public void setSalaDeEspera(Pacientes[] salaDeEspera) {
		this.salaDeEspera = salaDeEspera;
	}

	public Empleados[] getPersonas() {
		return personas;
	}

	public void setPersonas(Empleados[] personas) {
		this.personas = personas;
	}

	public void atenderSalaDeEspera(Pacientes[] salaDeEspera) {
		System.out.println("Se esta atendiendo al paciente "+ Pacientes.getNombre()+" de la sala de espera");
	}
	
	@Override
	public void comer() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void fichar() {
		// TODO Auto-generated method stub
		
	}
	
	public void asignarPersonas(Empleados empleado) {
		for (Personas persona : this.personas) {
		
			Empleados [] asientos = aula.getAsientos();
			asientos[asientoLibre]= alumno;
			System.out.println("Alumno "+alumno.getNombre() + " asignado "+
					" al aula "+ aula.getNumero());
			break; 
			}else {
				System.out.println("No hay asiento disponible para"
						+ " el alumno "+alumno.getNombre());
			}
		}
		
	}
	

}
