package pec2_Mar_Quispe;

public abstract class Empleados extends Personas implements Fichable{

	private int id;
	private int añosExperiencia;
	private String turno;
	
	public Empleados(String nombre, String apellidos, String dni, int id, int añosExperiencia, String turno) {
		super(nombre, apellidos, dni);
		this.id = id;
		this.añosExperiencia = añosExperiencia;
		this.turno = turno;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getAñosExperiencia() {
		return añosExperiencia;
	}

	public void setAñosExperiencia(int añosExperiencia) {
		this.añosExperiencia = añosExperiencia;
	}

	public String getTurno() {
		return turno;
	}

	public void setTurno(String turno) {
		this.turno = turno;
	}

	

	@Override
	public void comer() {
		// TODO Auto-generated method stub
		super.comer();
	}

	@Override
	public void fichar() {
		System.out.println("Los empleados estan fichando");
		
	}
	
	public abstract void examinarPaciente();
	public abstract Boolean atenderPaciente();
	
}
