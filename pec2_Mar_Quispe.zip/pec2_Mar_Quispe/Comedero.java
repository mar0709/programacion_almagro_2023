package pec2_Mar_Quispe;

public interface Comedero {
	void comer();

}
